package com.artifex.mupdfdemo;

interface EditInterface {
    void clickCopy();

    void clickHighLight();

    void clickUnderLight();

    void clickStrike();

}
